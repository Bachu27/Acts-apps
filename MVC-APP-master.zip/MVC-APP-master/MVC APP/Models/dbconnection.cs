﻿namespace MVC_APP.Models
{
    public class dbconnection
    {
        public int Id { get; set; }
        public string Name { get; set; }
            

    }
}
