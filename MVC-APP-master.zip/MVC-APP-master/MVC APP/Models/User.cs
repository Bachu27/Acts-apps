﻿namespace MVC_APP.Models
{
    public class User
    {
        String UserName { get; set; }
        String Password { get; set; }
        String Email { get; set; }


    }
}
